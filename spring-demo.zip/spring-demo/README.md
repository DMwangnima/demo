#### 静态数据注入

- 扩展spring，实现自定义schema标签和解析器
- 