package com.nuofankj.springdemo.common;

public interface Getter {

    Object getValue(Object value);

    Class<?> getClz();
}
