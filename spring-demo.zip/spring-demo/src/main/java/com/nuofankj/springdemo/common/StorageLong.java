package com.nuofankj.springdemo.common;

public class StorageLong<V> extends Storage<Long, V> {
}
