package com.nuofankj.springdemo.resource.bean;

public abstract class AbstractConsume implements IConsume {

    abstract void print();
}
