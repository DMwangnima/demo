package com.nuofankj.springdemo.resource.bean;

public abstract class AbstractReward implements IReward {

    abstract void print();

}
