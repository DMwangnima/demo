package com.nuofankj.springdemo.resource.bean;

public enum AttributeType {

    MAXHP,
    ATTACK,
    ;
}
