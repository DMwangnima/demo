package com.nuofankj.springdemo.resource.bean;

public enum ConsumeType {

    Currency,
    Item;
}
