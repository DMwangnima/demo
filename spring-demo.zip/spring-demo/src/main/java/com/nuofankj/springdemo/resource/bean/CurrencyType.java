package com.nuofankj.springdemo.resource.bean;

public enum CurrencyType {

    Gold,
    Coin,
    ;

}
