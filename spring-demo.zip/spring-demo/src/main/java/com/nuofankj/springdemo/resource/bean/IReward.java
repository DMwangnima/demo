package com.nuofankj.springdemo.resource.bean;

public interface IReward{
}
