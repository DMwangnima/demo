package com.nuofankj.springdemo.resource.bean;

import com.nuofankj.springdemo.support.PolyObjectMapper;

public class ImmutableAttribute extends Attribute implements PolyObjectMapper {
}
