package com.nuofankj.springdemo.resource.bean;

public class ItemPure {

    private int itemModelId;

    private int amount;

    @Override
    public String toString() {
        return "ItemPure{" +
                "itemModelId=" + itemModelId +
                ", amount=" + amount +
                '}';
    }
}
