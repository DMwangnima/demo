package com.nuofankj.springdemo.schema;

public enum InjectType {

    // 按类型注入
    CLASS,

    // 按标志
    NAME,
    ;
}
