package com.nuofankj.springdemo.schema;

public interface SchemaNames {

    String CONFIG_ELEMENT = "config";

    String PACKAGE_ELEMENT = "package";

    String FORMAT_ELEMENT = "format";

    String PAKCAGE_ATTRIBUTE_NAME = "name";

    String FORMAT_ATTRIBUTE_LOCATION = "location";

    String FORMAT_ATTRIBUTE_TYPE = "type";

    String FORMAT_ATTRIBUTE_SUFFIX = "suffix";
}
