package com.nuofankj.springdemo.support;

public interface PolyObjectMapper {
}
