package com.nuofankj.springdemo.support;

/**
 * 自我解析器，需要进行自我解析才需要使用该接口
 */
public interface SelfParser {

    void doParse();
}
