package com.nuofankj.springdemo.support;

public interface StringToObjectMapper {

    void parse(String content);
}
